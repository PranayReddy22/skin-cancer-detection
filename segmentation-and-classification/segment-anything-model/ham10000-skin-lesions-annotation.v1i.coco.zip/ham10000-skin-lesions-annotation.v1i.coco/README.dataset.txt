# ham10000-skin-lesions-annotation > 2024-11-22 6:11pm
https://universe.roboflow.com/deeplearningproject-7393p/ham10000-skin-lesions-annotation

Provided by a Roboflow user
License: CC BY 4.0

